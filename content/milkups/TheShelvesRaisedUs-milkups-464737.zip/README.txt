THE SHELVES RAISED US
by milkup (MilkUps)

8 tracks, cold vibes, fresh beats, straight from the cab-nets. 🥛
Retro 80s / synthwave. The music behind Spread Da Word.

TRACKLIST
01 - Trap Cabnets      (Trap)       0:55
02 - Lofi Midnight     (Lo-Fi)      1:39
03 - Electro Neon      (Electro)    1:00
04 - Pop Radio         (Pop)        1:05
05 - Country Fridge    (Country)    1:17
06 - Funk Cookout      (Funk)       1:11
07 - Synthwave Retro   (Synthwave)  1:09
08 - Icy               (Icy)        1:36

(c) 2026 MilkUps / Z-Dot LLC. All rights reserved.
MilkUps is an independent Z-Dot band. Music for Spread Da Word.
Web: https://milkups.zerric.xyz
Contact: milkups@zerric.xyz
